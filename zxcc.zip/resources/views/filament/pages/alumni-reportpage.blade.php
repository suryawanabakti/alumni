<x-filament-panels::page>
    <div>
        @livewire(\App\Livewire\AlumniReport::class)
    </div>
</x-filament-panels::page>
