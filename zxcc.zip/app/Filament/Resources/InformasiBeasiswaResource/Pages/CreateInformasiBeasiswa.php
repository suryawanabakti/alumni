<?php

namespace App\Filament\Resources\InformasiBeasiswaResource\Pages;

use App\Filament\Resources\InformasiBeasiswaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateInformasiBeasiswa extends CreateRecord
{
    protected static string $resource = InformasiBeasiswaResource::class;
}
